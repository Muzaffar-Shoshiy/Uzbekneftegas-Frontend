const loadText1 = document.querySelector(".a")
const loadText2 = document.querySelector(".b")
const loadText3 = document.querySelector(".c")
const loadText4 = document.querySelector(".d")
const loadText5 = document.querySelector(".e")
const loadText6 = document.querySelector(".f")
const loadText7 = document.querySelector(".g")

let load1 = 0
let load2 = 0
let load3 = 0
let load4 = 0
let load5 = 0
let load6 = 0
let load7 = 0

let int1 = setInterval(blurring1, 50)
let int2 = setInterval(blurring2, 50)
let int3 = setInterval(blurring3, 50)
let int4 = setInterval(blurring4, 50)
let int5 = setInterval(blurring5, 50)
let int6 = setInterval(blurring6, 50)
let int7 = setInterval(blurring7, 50)

function blurring1() {
    load1++
    if (load1 > 127) {
        clearInterval(int1)
    }
    loadText1.innerText = `${load1}`
}

function blurring2() {
    load2++
    if (load2 > 6) {
        clearInterval(int2)
    }
    loadText2.innerText = `${load2}`
}

function blurring3() {
    load3++
    if (load3 > 121) {
        clearInterval(int3)
    }
    loadText3.innerText = `${load3}`
}

function blurring4() {
    load4++
    if (load4 > 11) {
        clearInterval(int4)
    }
    loadText4.innerText = `${load4}`
}

function blurring5() {
    load5++
    if (load5 > 139) {
        clearInterval(int5)
    }
    loadText5.innerText = `${load5}`
}

function blurring6() {
    load6++
    if (load6 > 27) {
        clearInterval(int6)
    }
    loadText6.innerText = `${load6}`
}

function blurring7() {
    load7++
    if (load7 > 2) {
        clearInterval(int7)
    }
    loadText7.innerText = `${load7}`
}